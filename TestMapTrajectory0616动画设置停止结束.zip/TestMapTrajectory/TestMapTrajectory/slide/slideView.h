//
//  slideView.h
//  TestMapSlide
//
//  Created by wr on 15/6/12.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol slideViewDelegate<NSObject>
- (void)sldePlayPauseButton:(UIButton *)sender ;
@end
@interface slideView : UIView
@property (nonatomic , assign) id <slideViewDelegate> slideDelegate;
@end
