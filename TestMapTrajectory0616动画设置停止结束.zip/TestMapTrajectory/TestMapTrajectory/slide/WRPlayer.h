//
//  WRPlayer.h
//  TestMapSlide
//
//  Created by wr on 15/6/12.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <Foundation/Foundation.h>
@class WRPlayer;
@protocol WRPlayerDelegare <NSObject>
- (void)player:(WRPlayer *)player didReachPosition:(float)position;
- (void)playerDidStop:(WRPlayer *)player;
@end
@interface WRPlayer : NSObject
- (void)play;
- (void)pause;
@property (nonatomic, assign) float position;
@property (nonatomic, assign) id <WRPlayerDelegare> playerDelegate;
@end
