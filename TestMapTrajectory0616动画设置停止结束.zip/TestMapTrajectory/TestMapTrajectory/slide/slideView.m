//
//  slideView.m
//  TestMapSlide
//
//  Created by wr on 15/6/12.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "slideView.h"
#import "WRPlayer.h"
@interface slideView()<WRPlayerDelegare>
@property (weak, nonatomic) IBOutlet UIButton *playPauseButton;
@property (weak, nonatomic) IBOutlet UISlider *progressSlide;

@property (retain, nonatomic) WRPlayer * player;
@end
@implementation slideView
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(void)awakeFromNib{
    
    [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];
    
    self.player = [[WRPlayer alloc] init];
    self.player.playerDelegate = self;
    
    UIColor *tintColor = [UIColor orangeColor];
    [[UISlider appearance] setMinimumTrackTintColor:tintColor];
    
    [self.progressSlide addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    
}
#pragma mark - 只要滑块停放（注意是停放，如果要在拖动中也触发，请看后文）到新的位置 调用
- (void)sliderValueChanged:(UISlider *)slideSender
{
    if(slideSender == self.progressSlide){
        float value = slideSender.value;
        /* 添加处理进度条代码 */
        self.progressSlide.value = value;
    }

}
- (IBAction)progressSlideClick:(UISlider *)sender {
    
     self.player.position = sender.value;
    
}

- (IBAction)playPauseButtonClick:(UIButton *)sender {
    
    [self.slideDelegate sldePlayPauseButton:sender];
    
    if(sender.selected) // Shows the Pause symbol
    {
        [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];
        sender.selected = NO;
        [self.player pause];
    }
    else    // Shows the Play symbol
    {
        [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Pause"] forState:UIControlStateNormal];
        sender.selected = YES;
        [self.player play];
    }
    
}

- (void) player:(WRPlayer *)player didReachPosition:(float)position
{
    //    self.progressView.progress = position;
    self.progressSlide.value = position;
}

- (void) playerDidStop:(WRPlayer *)player
{
    [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];

    self.playPauseButton.selected = NO;
    //    self.progressView.progress = 0.0;
    self.progressSlide.value = 0.0;
}
@end
