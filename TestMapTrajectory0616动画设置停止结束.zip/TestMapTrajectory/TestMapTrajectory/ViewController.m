//
//  ViewController.m
//  TestMapTrajectory
//
//  Created by wr on 15/6/11.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "ViewController.h"
#import "TrajectoryViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *routeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [routeBtn setTitle:@"进入" forState:UIControlStateNormal];
    [routeBtn addTarget:self action:@selector(inrouteBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    routeBtn.frame = CGRectMake(0, 100, 50, 30);
    routeBtn.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:routeBtn];

    
    
}
- (void)inrouteBtnClick:(UIButton *)sender
{
    TrajectoryViewController * trajectoryVC = [[TrajectoryViewController alloc]init];
    [self presentViewController:trajectoryVC animated:YES completion:nil];
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
