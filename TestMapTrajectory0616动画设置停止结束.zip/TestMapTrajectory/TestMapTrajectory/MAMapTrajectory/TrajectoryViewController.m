//
//  TrajectoryViewController.m
//  carcareIOS
//
//  Created by wr on 15/6/11.
//  Copyright (c) 2015年 baozun. All rights reserved.
//

#import "TrajectoryViewController.h"
#import <AMapNaviKit/AMapNaviKit.h>
#import "NavPointAnnotation.h"
#import <MapKit/MapKit.h>
//#import "OMAMovingAnnotations.h"
#import "Tracking.h"

#import "slideView.h"
#define ARC4RANDOM_MAX 0x100000000

@interface TrajectoryViewController ()<AMapNaviViewControllerDelegate,AMapNaviManagerDelegate,MAMapViewDelegate ,TrackingDelegate, slideViewDelegate>
@property (nonatomic, strong) AMapNaviPoint * startPoint;
@property (nonatomic, strong) AMapNaviPoint * endPoint;

@property (nonatomic, strong) NSArray *annotations;

@property (nonatomic, strong) AMapNaviManager *naviManager;


@property (nonatomic, strong) MAMapView *mapView;

@property (nonatomic, strong) MAPolyline *polyline;

@property (nonatomic) BOOL calRouteSuccess; // 指示是否算路成功

//动画
//@property (assign, nonatomic) MACoordinateRegion region;

//@property (strong, nonatomic) OMAMovingAnnotationsAnimator *animator;

@property (nonatomic , strong) Tracking * tracking;
//纪录线路规划的这个值 用来动画的时候调用
@property (nonatomic ) NSUInteger coordianteCount;

@property (nonatomic, strong) AMapNaviRoute * naviRoute;
@end

@implementation TrajectoryViewController
@synthesize tracking = _tracking;
@synthesize coordianteCount = _coordianteCount;
- (id)init
{
    self = [super init];
    if (self)
    {
        [self initNaviPoints];
        
       
        
//        [AMapNaviServices sharedServices].apiKey = (NSString *)APIKey;
//        [MAMapServices sharedServices].apiKey = (NSString *)APIKey;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self initMapView];
    
    
    
    [self configSubViews];
    
    [self initNaviManager];
    
    [self initAnnotations];
    
    //添加动画大头针
//    [self setupMapView];
//    [self setupAnnotation];
//    [self.animator startAnimating];
}
//- (void)setupMapView {
//    CLLocationCoordinate2D OMAMapViewDefaultCenter  = (CLLocationCoordinate2D){ self.startPoint.latitude   , self.startPoint.longitude };
//    CLLocationDistance OMAMapViewDefaultSpanInMeters = 3000;
//    MACoordinateRegion region = MACoordinateRegionMakeWithDistance(OMAMapViewDefaultCenter, OMAMapViewDefaultSpanInMeters, OMAMapViewDefaultSpanInMeters);
//    [self.mapView setRegion:region];
////    self.region = region;
//}
//- (void)setupAnnotation {
//    self.animator = [[OMAMovingAnnotationsAnimator alloc] init];
//    
//    OMAMovePath *path = [[OMAMovePath alloc] init];
//    
//    CLLocationCoordinate2D start = [self randomCoordinateInRegion:self.region];
//    CLLocationCoordinate2D end = [self randomCoordinateInRegion:MACoordinateRegionMakeWithDistance( (CLLocationCoordinate2D){ self.endPoint.latitude   , self.endPoint.longitude },0, 0)];
//    
//    [path addSegment:OMAMovePathSegmentMake(start, end, [self randomDoubleBetweenMin:5 max:10])];
//    
//    OMAMovingAnnotation *annotation = [[OMAMovingAnnotation alloc] init];
//    annotation.coordinate = start;
//    annotation.movePath = path;
//    [annotation addObserver:self forKeyPath:@"moving" options:NSKeyValueObservingOptionNew context:NULL];
//    [self.mapView addAnnotation:annotation];
//    [self.animator addAnnotation:annotation];
//}
//- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
//    if ([keyPath isEqualToString:@"moving"]) {
//        BOOL moving = [change[NSKeyValueChangeNewKey] boolValue];
//        if (!moving) {
//            OMAMovingAnnotation *annotation = object;
//            if ([annotation.movePath isEmpty] && OMAMovePathSegmentIsNull(annotation.currentSegment)) {
//                OMAMovePathSegment segment = OMAMovePathSegmentMake(annotation.coordinate, [self randomCoordinateInRegion:self.region], [self randomDoubleBetweenMin:1 max:5]);
//                [annotation.movePath addSegment:segment];
//            }
//        }
//    } else {
//        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
//    }
//}
//
//- (void)dealloc {
//    for (OMAMovingAnnotation *annotation in self.mapView.annotations) {
//        [annotation removeObserver:self forKeyPath:@"moving"];
//    }
//}
//- (CLLocationCoordinate2D)randomCoordinateInRegion:(MACoordinateRegion)region {
//    CLLocationDegrees minLat = region.center.latitude - region.span.latitudeDelta / 2.;
//    CLLocationDegrees maxLat = region.center.latitude + region.span.latitudeDelta / 2.;
//    CLLocationDegrees minLon = region.center.longitude - region.span.longitudeDelta / 2.;
//    CLLocationDegrees maxLon = region.center.longitude + region.span.longitudeDelta / 2.;
//    return CLLocationCoordinate2DMake([self randomDoubleBetweenMin:minLat max:maxLat],
//                                      [self randomDoubleBetweenMin:minLon max:maxLon]);
//}
//- (double)randomDoubleBetweenMin:(double)min max:(double)max {
//    return ((double)arc4random() / ARC4RANDOM_MAX) * (max - min) + min;
//}
- (void)viewDidDisappear:(BOOL)animated
{
    [self.tracking  clear];
    
}
#pragma mark - Initialization

- (void)initMapView
{
    
    [MAMapServices sharedServices].apiKey = @"54b91f0923327eef82b4871f80738140";
    if (self.mapView == nil)
    {
        self.mapView = [[MAMapView alloc] initWithFrame:self.view.bounds];
    }
    
    self.mapView.frame = self.view.bounds;
    
    self.mapView.delegate = self;
    
    
    self.mapView.visibleMapRect = MAMapRectMake(220880104, 101476980, 272496, 466656);

    [self.view addSubview:self.mapView];
}
- (void)configSubViews
{
    
    UILabel *startPointLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 45, 320, 20)];
    
    startPointLabel.textAlignment = NSTextAlignmentCenter;
    startPointLabel.font          = [UIFont systemFontOfSize:14];
    startPointLabel.text          = [NSString stringWithFormat:@"起 点：%f, %f", _startPoint.latitude, _startPoint.longitude];
    
    [self.view addSubview:startPointLabel];
    
    UILabel *endPointLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 75, 320, 20)];
    
    endPointLabel.textAlignment = NSTextAlignmentCenter;
    endPointLabel.font          = [UIFont systemFontOfSize:14];
    endPointLabel.text          = [NSString stringWithFormat:@"终 点：%f, %f", _endPoint.latitude, _endPoint.longitude];
    
    [self.view addSubview:endPointLabel];
    
    UIButton *routeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [routeBtn setTitle:@"路径规划" forState:UIControlStateNormal];
    [routeBtn addTarget:self action:@selector(routeCal) forControlEvents:UIControlEventTouchUpInside];
    routeBtn.backgroundColor = [UIColor redColor];
    routeBtn.frame = CGRectMake(0, 100, 100, 50);
    [self.view addSubview:routeBtn];
    
    UIButton *animationBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [animationBtn setTitle:@"动画" forState:UIControlStateNormal];
    [animationBtn addTarget:self action:@selector(animationBtnClick) forControlEvents:UIControlEventTouchUpInside];
    animationBtn.backgroundColor = [UIColor yellowColor];
    animationBtn.frame = CGRectMake(100, 100, 100, 50);
    [self.view addSubview:animationBtn];
   
    
    
    
    slideView * slideView = [[[NSBundle mainBundle] loadNibNamed:@"slideView" owner:self options:nil] firstObject];
    slideView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height  - 50, [UIScreen mainScreen].bounds.size.width, 50);
    slideView.slideDelegate = self;
    [self.view addSubview:slideView];
    
    [self routeCal];
}
#pragma mark - slideview delegate
- (void)sldePlayPauseButton:(UIButton *)sender
{
    if(sender.selected) // Shows the Pause symbol
    {
        
//        [self.tracking clear];
        [self.tracking stop];
    }
    else    // Shows the Play symbol
    {
        
        [self animationBtnClick];
        
    }

    

}
- (void)animationBtnClick
{
    if (self.tracking == nil)
    {
        [self setupTracking:self.naviRoute];
    }
    
    [self.tracking execute];

}
//动画
/* 构建轨迹回放. */
- (void)setupTracking:(AMapNaviRoute *)naviRoute
{
//    NSString *trackingFilePath = [[NSBundle mainBundle] pathForResource:@"GuGong" ofType:@"tracking"];
//    
//    NSData *trackingData = [NSData dataWithContentsOfFile:trackingFilePath];
//    
//    CLLocationCoordinate2D *coordinates = (CLLocationCoordinate2D *)malloc(trackingData.length);
//    
//    /* 提取轨迹原始数据. */
//    [trackingData getBytes:coordinates length:trackingData.length];
    
    
    CLLocationCoordinate2D coordinates[self.coordianteCount];
    for (int i = 0; i < self.coordianteCount; i++)
    {
        AMapNaviPoint *aCoordinate = [naviRoute.routeCoordinates objectAtIndex:i];
        coordinates[i] = CLLocationCoordinate2DMake(aCoordinate.latitude, aCoordinate.longitude);
    }
    
    /* 构建tracking. */
    self.tracking = [[Tracking alloc] initWithCoordinates:coordinates count:self.coordianteCount];
    self.tracking.delegate = self;
    self.tracking.mapView  = self.mapView;
    self.tracking.duration = 5.f;
    self.tracking.edgeInsets = UIEdgeInsetsMake(50, 50, 50, 50);
}

- (void)routeCal
{
    NSArray *startPoints = @[_startPoint];
    NSArray *endPoints   = @[_endPoint];
    
    [self.naviManager calculateDriveRouteWithStartPoints:startPoints endPoints:endPoints wayPoints:nil drivingStrategy:0];
    
    
}
- (void)initNaviManager
{
    if (self.naviManager == nil)
    {
        _naviManager = [[AMapNaviManager alloc] init];
        [_naviManager setDelegate:self];
    }
}

#pragma mark - Construct and Inits

- (void)initNaviPoints
{
    _startPoint = [AMapNaviPoint locationWithLatitude:39.989614 longitude:116.481763];
    _endPoint   = [AMapNaviPoint locationWithLatitude:39.983456 longitude:116.315495];
}
- (void)initAnnotations
{
    NavPointAnnotation *beginAnnotation = [[NavPointAnnotation alloc] init];
    
    [beginAnnotation setCoordinate:CLLocationCoordinate2DMake(_startPoint.latitude, _startPoint.longitude)];
    beginAnnotation.title        = @"起始点";
    beginAnnotation.navPointType = NavPointAnnotationStart;
    
    NavPointAnnotation *endAnnotation = [[NavPointAnnotation alloc] init];
    
    [endAnnotation setCoordinate:CLLocationCoordinate2DMake(_endPoint.latitude, _endPoint.longitude)];
    
    endAnnotation.title        = @"终点";
    endAnnotation.navPointType = NavPointAnnotationEnd;
    
    self.annotations = @[ beginAnnotation ,endAnnotation];
    [self.mapView addAnnotations:self.annotations];
    
    //构造折线对象
//    MAPolyline *commonPolyline = [MAPolyline polylineWithCoordinates:commonPolylineCoords count:4];
//    
//    //在地图上添加折线对象
//    [_mapView addOverlay: commonPolyline];
    
}
#pragma mark  - line Delegate
- (void)AMapNaviManagerOnCalculateRouteSuccess:(AMapNaviManager *)naviManager
{
    
    [self showRouteWithNaviRoute:[[naviManager naviRoute] copy]];
    _calRouteSuccess = YES;
}

- (void)showRouteWithNaviRoute:(AMapNaviRoute *)naviRoute
{
    if (naviRoute == nil) return;
    
    // 清除旧的overlays
    if (_polyline)
    {
        [self.mapView removeOverlay:_polyline];
        self.polyline = nil;
    }
    /*
     //构造折线数据对象
     CLLocationCoordinate2D commonPolylineCoords[4];
     commonPolylineCoords[0].latitude = 39.832136;
     commonPolylineCoords[0].longitude = 116.34095;
     
     commonPolylineCoords[1].latitude = 39.832136;
     commonPolylineCoords[1].longitude = 116.42095;
     
     commonPolylineCoords[2].latitude = 39.902136;
     commonPolylineCoords[2].longitude = 116.42095;
     
     commonPolylineCoords[3].latitude = 39.902136;
     commonPolylineCoords[3].longitude = 116.44095;
     */
    NSUInteger coordianteCount = [naviRoute.routeCoordinates count];
    self.coordianteCount = coordianteCount;
    CLLocationCoordinate2D coordinates[coordianteCount];

    for (int i = 0; i < coordianteCount; i++)
    {
        AMapNaviPoint *aCoordinate = [naviRoute.routeCoordinates objectAtIndex:i];
        coordinates[i] = CLLocationCoordinate2DMake(aCoordinate.latitude, aCoordinate.longitude);
    }
    
    //构造折线对象
    _polyline = [MAPolyline polylineWithCoordinates:coordinates count:coordianteCount];
    //在地图上添加折线对象
    [self.mapView addOverlay:_polyline];
    
    [self setupTracking:naviRoute];
    self.naviRoute = naviRoute;
    
}

#pragma mark - MAMapView Delegate
- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MAPointAnnotation class]])
    {
        static NSString *reuseIndetifier = @"annotationReuseIndetifier";
        MAAnnotationView *annotationView = (MAAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:reuseIndetifier];
        if (annotationView == nil)
        {
            annotationView = [[MAAnnotationView alloc] initWithAnnotation:annotation
                                                          reuseIdentifier:reuseIndetifier];
        }
        annotationView.image = [UIImage imageNamed:@"restaurant"];
        //设置中⼼心点偏移，使得标注底部中间点成为经纬度对应点
        annotationView.centerOffset = CGPointMake(0, 0);
        annotationView.frame = CGRectMake(0, 0, 30, 30);
        return annotationView;
    }
     //动画
    if (annotation == self.tracking.annotation)
    {
        static NSString *trackingReuseIndetifier = @"trackingReuseIndetifier";
        
        MAAnnotationView *annotationView = [mapView dequeueReusableAnnotationViewWithIdentifier:trackingReuseIndetifier];
        
        if (annotationView == nil)
        {
            annotationView = [[MAAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:trackingReuseIndetifier];
        }
        
        annotationView.canShowCallout = NO;
        annotationView.image = [UIImage imageNamed:@"restaurant"];
        
        return annotationView;
    }

    return nil;
}
//- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation
//{
//    if ([annotation isKindOfClass:[NavPointAnnotation class]])
//    {
//        static NSString *annotationIdentifier = @"annotationIdentifier";
//        
//        MAPinAnnotationView *pointAnnotationView = (MAPinAnnotationView*)[self.mapView dequeueReusableAnnotationViewWithIdentifier:annotationIdentifier];
//        if (pointAnnotationView == nil)
//        {
//            pointAnnotationView = [[MAPinAnnotationView alloc] initWithAnnotation:annotation
//                                                                  reuseIdentifier:annotationIdentifier];
//        }
//        
//        pointAnnotationView.animatesDrop   = NO;
//        pointAnnotationView.canShowCallout = YES;
//        pointAnnotationView.draggable      = NO;
//        
//        NavPointAnnotation *navAnnotation = (NavPointAnnotation *)annotation;
//        
//        if (navAnnotation.navPointType == NavPointAnnotationStart)
//        {
//            [pointAnnotationView setPinColor:MAPinAnnotationColorGreen];
//        }
//        else if (navAnnotation.navPointType == NavPointAnnotationEnd)
//        {
//            [pointAnnotationView setPinColor:MAPinAnnotationColorRed];
//        }
//        return pointAnnotationView;
//    }
//    
//    return nil;
//}

#pragma mark - 继续在ViewController.m文件中，实现<MAMapViewDelegate>协议中的mapView:viewForOverlay:回调函数，设置折线的样式。示例代码如下
- (MAOverlayView *)mapView:(MAMapView *)mapView viewForOverlay:(id<MAOverlay>)overlay
{
    if ([overlay isKindOfClass:[MAPolyline class]])
    {
        MAPolylineView *polylineView = [[MAPolylineView alloc] initWithPolyline:overlay];
        
        polylineView.lineWidth   = 5.0f;
        polylineView.strokeColor = [UIColor redColor];
        polylineView.lineJoinType = kMALineJoinRound;//连接类型
        polylineView.lineCapType = kMALineCapRound;//端点类型
        return polylineView;
    }
    //动画
    if (overlay == self.tracking.polyline)
    {
        MAPolylineView *polylineView = [[MAPolylineView alloc] initWithPolyline:overlay];
        
        polylineView.lineWidth   = 4.f;
        polylineView.strokeColor = [UIColor blackColor];
        
        return polylineView;
    }
    return nil;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
