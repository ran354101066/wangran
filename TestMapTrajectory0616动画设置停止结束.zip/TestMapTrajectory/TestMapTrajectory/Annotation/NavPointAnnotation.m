//
//  NavPointAnnotation.m
//  officialDemoNavi
//
//  Created by LiuX on 14-8-26.
//  Copyright (c) 2014年 AutoNavi. All rights reserved.
//

#import "NavPointAnnotation.h"

@implementation NavPointAnnotation

@end
