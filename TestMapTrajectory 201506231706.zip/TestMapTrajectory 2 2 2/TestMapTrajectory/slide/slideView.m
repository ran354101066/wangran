//
//  slideView.m
//  TestMapSlide
//
//  Created by wr on 15/6/12.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "slideView.h"
//#import "WRPlayer.h"
@interface slideView()
@property (weak, nonatomic) IBOutlet UIButton *playPauseButton;
@property (weak, nonatomic) IBOutlet UISlider *progressSlide;
@end
@implementation slideView
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(void)awakeFromNib{
    
    [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];

    UIColor *tintColor = [UIColor orangeColor];
    [[UISlider appearance] setMinimumTrackTintColor:tintColor];
    
    [self.progressSlide addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    
}
#pragma mark - 只要滑块停放（注意是停放，如果要在拖动中也触发，请看后文）到新的位置 调用
- (void)sliderValueChanged:(UISlider *)slideSender
{
    if(slideSender == self.progressSlide){
        float value = slideSender.value;
        /* 添加处理进度条代码 */
        self.progressSlide.value = value;
        [self.slideDelegate slideProgress:self.progressSlide changeValue:value];
    }

}
- (IBAction)progressSlideClick:(UISlider *)sender {
    
     self.progressSlide.value = sender.value;
    
}

- (IBAction)playPauseButtonClick:(UIButton *)sender {
    
    [self.slideDelegate sldePlayPauseButton:sender];
    [self.slideDelegate slideProgress:self.progressSlide changeValue:0];
    
    if(sender.selected) // Shows the Pause symbol
    {
        [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];
        sender.selected = NO;
    }
    else    // Shows the Play symbol
    {
        [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Pause"] forState:UIControlStateNormal];
        sender.selected = YES;
    }
    
}

@end
