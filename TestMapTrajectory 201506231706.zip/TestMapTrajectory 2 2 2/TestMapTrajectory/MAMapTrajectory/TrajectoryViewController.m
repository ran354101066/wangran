//
//  TrajectoryViewController.m
//  carcareIOS
//
//  Created by wr on 15/6/11.
//  Copyright (c) 2015年 baozun. All rights reserved.
//

#import "TrajectoryViewController.h"
#import <AMapNaviKit/AMapNaviKit.h>
#import "NavPointAnnotation.h"
#import <MapKit/MapKit.h>
#import "slideView.h"

#import "WRMovingAnnotion.h"
#import "CustomAnnotationView.h"
#define ARC4RANDOM_MAX 0x100000000

@interface TrajectoryViewController ()<AMapNaviViewControllerDelegate,AMapNaviManagerDelegate,MAMapViewDelegate,slideViewDelegate,WRMovingAnnotionDelegate>
{
    //动画
    WRMovingAnnotion * annotationAnimation;
}
@property (nonatomic, strong) AMapNaviPoint * startPoint;
@property (nonatomic, strong) AMapNaviPoint * endPoint;

@property (nonatomic, strong) NSArray *annotations;

@property (nonatomic, strong) AMapNaviManager *naviManager;


@property (nonatomic, strong) MAMapView *mapView;

@property (nonatomic, strong) MAPolyline *polyline;

@property (nonatomic) BOOL calRouteSuccess; // 指示是否算路成功

//动画
@property (nonatomic, strong)NSMutableArray * moveAnnotionArray;

//纪录线路规划的这个值 用来动画的时候调用
@property (nonatomic ) NSUInteger coordianteCount;
@property (nonatomic, strong) AMapNaviRoute * naviRoute;

@property (nonatomic )NSInteger positonChangeNum;

@property (nonatomic, strong)UISlider * mapSlide;

@property (nonatomic ,strong)UIButton * playPauseButton;

@property (nonatomic) NSInteger annotionTagNum;
@end

@implementation TrajectoryViewController
- (id)init
{
    self = [super init];
    if (self)
    {
        [self initNaviPoints];
        
        [self initNaviManager];

    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self initMapView];
    [self configSubViews];
    [self initAnnotations];
    //添加动画大头针
    [self setUpAnnotation];
    
    
    [self.mapView setRotateEnabled:YES];
}
- (void)setUpAnnotation
{

    self.annotionTagNum = 52;
    annotationAnimation = [[WRMovingAnnotion alloc] initWithMapView:self.mapView ];
    annotationAnimation.coordinate = CLLocationCoordinate2DMake(_startPoint.latitude, _startPoint.longitude);
    annotationAnimation.moveDelegate = self;
    [self.mapView addAnnotation:annotationAnimation];

}
#pragma mark - WRMovingAnnotation delegate
- (void)moveListeningToTheNum:(NSInteger)moveNumIndex
{
    self.positonChangeNum = moveNumIndex;
    //设置slider
    if (self.mapSlide != nil ) {
        self.mapSlide.value = 1.0 / self.coordianteCount * self.positonChangeNum;
    }
    if (self.positonChangeNum == self.coordianteCount - 1 )
    {
        
        self.mapSlide.value = 0;
        BOOL buttonBool = !self.playPauseButton.selected;
        [self.playPauseButton setSelected:buttonBool];
        [self.playPauseButton setImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];
    }else if(self.positonChangeNum== 1)
    {
       
        [self.playPauseButton setImage:[UIImage imageNamed:@"pause"] forState:UIControlStateNormal];
    }else if(self.positonChangeNum == self.coordianteCount - 2)
    {
        //用来调节  一次动画结束后 回到首位的动画
        self.annotionTagNum = 52;
    }

}
#pragma mark - Initialization

- (void)initMapView
{
    if (self.mapView == nil)
    {
        self.mapView = [[MAMapView alloc] initWithFrame:self.view.bounds];
    }
    
    self.mapView.frame = self.view.bounds;
    
    self.mapView.delegate = self;
    
    
    self.mapView.visibleMapRect = MAMapRectMake(220880104, 101476980, 272496, 466656);

    [self.view addSubview:self.mapView];
}
- (void)configSubViews
{
    UILabel *startPointLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 45, 320, 20)];
    
    startPointLabel.textAlignment = NSTextAlignmentCenter;
    startPointLabel.font          = [UIFont systemFontOfSize:14];
    startPointLabel.text          = [NSString stringWithFormat:@"起 点：%f, %f", _startPoint.latitude, _startPoint.longitude];
    [self.view addSubview:startPointLabel];
    
    UILabel *endPointLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 75, 320, 20)];
    
    endPointLabel.textAlignment = NSTextAlignmentCenter;
    endPointLabel.font          = [UIFont systemFontOfSize:14];
    endPointLabel.text          = [NSString stringWithFormat:@"终 点：%f, %f", _endPoint.latitude, _endPoint.longitude];
    
    [self.view addSubview:endPointLabel];
    
    UIButton *routeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [routeBtn setTitle:@"路径规划" forState:UIControlStateNormal];
    [routeBtn addTarget:self action:@selector(routeCal) forControlEvents:UIControlEventTouchUpInside];
    routeBtn.backgroundColor = [UIColor redColor];
    routeBtn.frame = CGRectMake(0, 100, 100, 50);
    [self.view addSubview:routeBtn];
    
    slideView * slideView = [[[NSBundle mainBundle] loadNibNamed:@"slideView" owner:self options:nil] firstObject];
    slideView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height  - 50, [UIScreen mainScreen].bounds.size.width, 50);
    slideView.slideDelegate = self;
    [self.view addSubview:slideView];
    

   
    [self routeCal];
}
#pragma mark - slideview delegate
- (void)slideProgress:(UISlider *)slider changeValue:(float)value
{
    
    NSLog(@"~~~~~~%f",value);
    self.mapSlide = slider;
    self.mapSlide.value = slider.value;

}
- (void)sldePlayPauseButton:(UIButton *)sender
{
    self.playPauseButton = sender;
//     self.playPauseSelectedBool = sender.selected;
    if(sender.selected) // Shows the Pause symbol
    {
        [annotationAnimation stopMoveAnimation];
//        [self.animator stopAnimating];
    }
    else
    {
        [annotationAnimation startMoveAnimationWithMove:self.moveAnnotionArray];
         self.annotionTagNum = 51;
//        [self.animator startAnimating];
        
    }

    
}

- (void)routeCal
{
    NSArray *startPoints = @[_startPoint];
    NSArray *endPoints   = @[_endPoint];
    
    [self.naviManager calculateDriveRouteWithStartPoints:startPoints endPoints:endPoints wayPoints:nil drivingStrategy:0];
    
}
- (void)initNaviManager
{
    self.annotionTagNum = 50;
    
    if (self.naviManager == nil)
    {
        _naviManager = [[AMapNaviManager alloc] init];
        [_naviManager setDelegate:self];
    }
}

#pragma mark - Construct and Inits

- (void)initNaviPoints
{
    _startPoint = [AMapNaviPoint locationWithLatitude:39.989614 longitude:116.481763];
    _endPoint   = [AMapNaviPoint locationWithLatitude:39.983456 longitude:116.315495];
}
- (void)initAnnotations
{
    NavPointAnnotation *beginAnnotation = [[NavPointAnnotation alloc] init];
    
    [beginAnnotation setCoordinate:CLLocationCoordinate2DMake(_startPoint.latitude, _startPoint.longitude)];
    beginAnnotation.title        = @"起始点";
    beginAnnotation.subtitle     = @"start";
    beginAnnotation.navPointType = NavPointAnnotationStart;
    
    NavPointAnnotation *endAnnotation = [[NavPointAnnotation alloc] init];
    
    [endAnnotation setCoordinate:CLLocationCoordinate2DMake(_endPoint.latitude, _endPoint.longitude)];
    
    endAnnotation.title        = @"终点";
    endAnnotation.subtitle     = @"end";
    endAnnotation.navPointType = NavPointAnnotationEnd;
    
    self.annotations = @[beginAnnotation, endAnnotation];
    [self.mapView addAnnotations:self.annotations];
    
    //构造折线对象
//    MAPolyline *commonPolyline = [MAPolyline polylineWithCoordinates:commonPolylineCoords count:4];
//    
//    //在地图上添加折线对象
//    [_mapView addOverlay: commonPolyline];
    
}
#pragma mark  - line Delegate
- (void)AMapNaviManagerOnCalculateRouteSuccess:(AMapNaviManager *)naviManager
{
    
    [self showRouteWithNaviRoute:[[naviManager naviRoute] copy]];
    
    _calRouteSuccess = YES;
}

- (void)showRouteWithNaviRoute:(AMapNaviRoute *)naviRoute
{
    if (naviRoute == nil) return;
    
    // 清除旧的overlays
    if (_polyline)
    {
        [self.mapView removeOverlay:_polyline];
        self.polyline = nil;
    }
    self.moveAnnotionArray = [NSMutableArray arrayWithArray:naviRoute.routeCoordinates];
    NSUInteger coordianteCount = [naviRoute.routeCoordinates count];
    CLLocationCoordinate2D coordinates[coordianteCount];
    for (int i = 0; i < coordianteCount; i++)
    {
        AMapNaviPoint *aCoordinate = [naviRoute.routeCoordinates objectAtIndex:i];
        coordinates[i] = CLLocationCoordinate2DMake(aCoordinate.latitude, aCoordinate.longitude);
    }
    NSLog(@"%@",naviRoute.routeCoordinates);
    //动画使用
    self.naviRoute = naviRoute;
    self.coordianteCount = coordianteCount;
    
    //构造折线对象
    _polyline = [MAPolyline polylineWithCoordinates:coordinates count:coordianteCount];
    //在地图上添加折线对象
    [self.mapView addOverlay:_polyline];
    
    
}

#pragma mark - MAMapView Delegate
- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MAPointAnnotation class]])
    {
        static NSString *reuseIndetifier = @"annotationReuseIndetifier";
        CustomAnnotationView *annotationView = (CustomAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:reuseIndetifier];
        if (annotationView == nil)
        {
            annotationView = [[CustomAnnotationView alloc] initWithAnnotation:annotation
                                                          reuseIdentifier:reuseIndetifier];
            annotationView.tag = self.annotionTagNum;
        }
        annotationView.image = [UIImage imageNamed:@"restaurant"];
        // 设置为NO，用以调用自定义的calloutView
        annotationView.canShowCallout = NO;
        
        //设置中⼼心点偏移，使得标注底部中间点成为经纬度对应点
        annotationView.centerOffset = CGPointMake(0, 0);
        annotationView.frame = CGRectMake(0, 0, 30, 30);
        
        //如果是起始位置 不显示气泡
        if (annotationView.tag == 50) {
            annotationView.selected = NO;
        }else
        {
            annotationView.selected = YES;
        }
        return annotationView;
    }
    
    if ([annotation isKindOfClass:[WRMovingAnnotion class]]) {
        static NSString *reuseIndetifier = @"moveAnnotation";
        MAAnnotationView *annotationView = (MAAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:reuseIndetifier];
        if (annotationView == nil)
        {
            annotationView = [[MAAnnotationView alloc] initWithAnnotation:annotation
                                                          reuseIdentifier:reuseIndetifier];
        }
        annotationView.image = [UIImage imageNamed:@"restaurant"];
        //设置中⼼心点偏移，使得标注底部中间点成为经纬度对应点
        annotationView.centerOffset = CGPointMake(30, 100);
        annotationView.frame = CGRectMake(0, 0, 30, 30);
        return annotationView;
    }

    return nil;
}

#pragma mark - 继续在ViewController.m文件中，实现<MAMapViewDelegate>协议中的mapView:viewForOverlay:回调函数，设置折线的样式。示例代码如下
- (MAOverlayView *)mapView:(MAMapView *)mapView viewForOverlay:(id<MAOverlay>)overlay
{
    if ([overlay isKindOfClass:[MAPolyline class]])
    {
        MAPolylineView *polylineView = [[MAPolylineView alloc] initWithPolyline:overlay];
        
        polylineView.lineWidth   = 5.0f;
        polylineView.strokeColor = [UIColor redColor];
        polylineView.lineJoinType = kMALineJoinRound;//连接类型
        polylineView.lineCapType = kMALineCapRound;//端点类型
        return polylineView;
    }
    return nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
