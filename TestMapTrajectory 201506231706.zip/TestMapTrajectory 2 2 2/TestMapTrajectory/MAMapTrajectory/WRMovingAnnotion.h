//
//  WRMovingAnnotion.h
//  TestMapTrajectory
//
//  Created by wr on 15/6/17.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AMapNaviKit/MAMapKit.h>
@protocol WRMovingAnnotionDelegate<NSObject>
//监控走的数量 ，用来返回 监听改变slider
- (void)moveListeningToTheNum:(NSInteger)moveNumIndex;
@end

@interface WRMovingAnnotion : NSObject<MAAnnotation>

- (instancetype)initWithMapView:(MAMapView *)mapView ;

@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, assign) id <WRMovingAnnotionDelegate> moveDelegate;
//开始大头针动画
- (void)startMoveAnimationWithMove:(NSMutableArray *)moveAnnotation;
//停止动画
- (void)stopMoveAnimation;

@end
