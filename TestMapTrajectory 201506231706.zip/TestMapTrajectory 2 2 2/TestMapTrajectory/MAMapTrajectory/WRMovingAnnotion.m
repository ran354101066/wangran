//
//  WRMovingAnnotion.m
//  TestMapTrajectory
//
//  Created by wr on 15/6/17.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "WRMovingAnnotion.h"
#import "NavPointAnnotation.h"

@interface WRMovingAnnotion()<MAMapViewDelegate>
@property (nonatomic , strong) MAMapView * mapView;
@property (nonatomic , strong)NavPointAnnotation * oldAnnotation;
@property (nonatomic , strong)NSTimer * timer;
//数组坐标
@property (nonatomic )NSInteger moveNumIndex;
@property (nonatomic , strong) NSMutableArray * moveAnnotationArray;
@end

@implementation WRMovingAnnotion

- (instancetype)initWithMapView:(MAMapView *)mapView 
{
    self = [super init];
    if(self)
    {
        self.mapView = mapView;
       
    }
    return self;
}
- (void)setCoordinate:(CLLocationCoordinate2D)coordinate
{
    [self starAnnotation:coordinate];
}
- (void)starAnnotation:(CLLocationCoordinate2D)coordinate
{
    NavPointAnnotation *starAnnotation = [[NavPointAnnotation alloc] init];
    
    [starAnnotation setCoordinate:CLLocationCoordinate2DMake(coordinate.latitude, coordinate.longitude)];
    starAnnotation.navPointType = NavPointAnnotationStart;
    starAnnotation.title        = @"起始点";
    starAnnotation.subtitle     = @"start";
    self.oldAnnotation = starAnnotation;
    [self.mapView addAnnotation:starAnnotation];
    
    self.moveNumIndex = 0;
}
- (void)startMoveAnimationWithMove:(NSMutableArray *)moveAnnotation
{
    self.moveAnnotationArray = [NSMutableArray arrayWithArray:moveAnnotation];
    self.timer = [NSTimer timerWithTimeInterval:0.08 target:self selector:@selector(moveAnnotation) userInfo:nil repeats:YES];
    [self.timer fire];
    NSRunLoop *runLoop = [NSRunLoop currentRunLoop];
    [runLoop addTimer:self.timer forMode:NSDefaultRunLoopMode];
}
- (void)moveAnnotation
{
    self.moveNumIndex ++;
    [self.mapView removeAnnotation:self.oldAnnotation];
    
    if (self.moveNumIndex < self.moveAnnotationArray.count) {
        NavPointAnnotation * wayAnnotation = [[NavPointAnnotation alloc] init];
        AMapNaviPoint * aCoordinate = [self.moveAnnotationArray objectAtIndex:self.moveNumIndex];
        [wayAnnotation setCoordinate:CLLocationCoordinate2DMake(aCoordinate.latitude, aCoordinate.longitude)];
        wayAnnotation.navPointType = NavPointAnnotationWay;
        self.oldAnnotation = wayAnnotation;
        
        wayAnnotation.title        = @"起始点";
        wayAnnotation.subtitle     = @"start";
        [self.mapView addAnnotation:wayAnnotation];
        
        [self.moveDelegate moveListeningToTheNum:self.moveNumIndex];
    }else
    {
        AMapNaviPoint * aCoordinate = [self.moveAnnotationArray objectAtIndex: 0];
        [self starAnnotation:CLLocationCoordinate2DMake(aCoordinate.latitude, aCoordinate.longitude)];
        [self stopMoveAnimation];
    }
    

}
- (void)stopMoveAnimation
{
    [self.timer invalidate];
    self.timer = nil;
    
}
@end
