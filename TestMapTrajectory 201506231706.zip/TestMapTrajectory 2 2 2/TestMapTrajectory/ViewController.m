//
//  ViewController.m
//  TestMapTrajectory
//
//  Created by wr on 15/6/11.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "ViewController.h"
#import "TrajectoryViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *routeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [routeBtn setTitle:@"路径规划" forState:UIControlStateNormal];
    [routeBtn addTarget:self action:@selector(routeCal:) forControlEvents:UIControlEventTouchUpInside];
    routeBtn.frame = CGRectMake(0, 100, 50, 30);
    routeBtn.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:routeBtn];

//    [self routeCal:routeBtn];
    
}
- (void)routeCal:(UIButton *)sender
{
    TrajectoryViewController * trajectoryVC = [[TrajectoryViewController alloc]init];
    UINavigationController * navi = [[UINavigationController alloc]initWithRootViewController:trajectoryVC];
    [self presentViewController:navi animated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
