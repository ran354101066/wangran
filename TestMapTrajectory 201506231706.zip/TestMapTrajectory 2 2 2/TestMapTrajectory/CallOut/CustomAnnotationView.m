//
//  CustomAnnotationView.m
//  TestMapTrajectory
//
//  Created by wr on 15/6/17.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "CustomAnnotationView.h"

//#define kCalloutWidth       200.0
//#define kCalloutHeight      70.0

@interface CustomAnnotationView ()
{
    CGFloat kCalloutWidth ;
    CGFloat kCalloutHeight ;

}
@property (nonatomic, strong, readwrite) CustomCalloutView *calloutView;

@end

@implementation CustomAnnotationView
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    //tag = 50 是起始点   路途中 tag ＝ 51 途中的起点 tag ＝ 52
    if (self.tag == 50 || self.tag == 52) {
        kCalloutWidth = 200.0;
        kCalloutHeight = 70.0;
//        if (self.selected == selected)
//        {
//            self.selected = !self.selected;
//            return;
//        }
    }else if(self.tag == 51)
    {
//        if (self.selected == selected)
//        {
//            return;
//        }
        kCalloutWidth = 100.0;
        kCalloutHeight = 70.0;
    }
    if (self.selected == selected)
    {
        return;
    }
    if (selected)
    {
        if (self.calloutView == nil)
        {
//            self.calloutView.tag = self.tag;
            
            self.calloutView = [[CustomCalloutView alloc] initWithFrame:CGRectMake(0, 0, kCalloutWidth, kCalloutHeight) withTag:self.tag];
            self.calloutView.center = CGPointMake(CGRectGetWidth(self.bounds) / 2.f + self.calloutOffset.x,
                                                  -CGRectGetHeight(self.calloutView.bounds) / 2.f + self.calloutOffset.y);
            
        }
        
        self.calloutView.image = [UIImage imageNamed:@"building"];
        self.calloutView.title = self.annotation.title;
        self.calloutView.subtitle = self.annotation.subtitle;
        
        [self addSubview:self.calloutView];
    }
    else
    {
        [self.calloutView removeFromSuperview];
    }
    [super setSelected:selected animated:animated];
}


@end
