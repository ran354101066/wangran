//
//  CustomCalloutView.m
//  TestMapTrajectory
//
//  Created by wr on 15/6/17.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "CustomCalloutView.h"

// 起始大头针使用的气泡 大小
#define kArrorHeight        10

#define kPortraitMargin     5
#define kPortraitWidth      70
#define kPortraitHeight     50

#define kTitleWidth         120
#define kTitleHeight        20


@interface CustomCalloutView ()
// 起始大头针使用的气泡
@property (nonatomic, strong) UIImageView *portraitView;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UILabel *titleLabel;
// 途中大头针使用的气泡
@property (nonatomic, strong)UILabel * smallViewTimeLabel;
@property (nonatomic, strong)UILabel * smallViewDistanceLabel;
@property (nonatomic, strong)UILabel * smallViewUnitsLabel;

@end
@implementation CustomCalloutView
- (instancetype)initWithFrame:(CGRect)frame withTag:(NSInteger)selfTag
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.tag  = selfTag;
        self.backgroundColor = [UIColor clearColor];
        //起始大头针  自定义
        if (self.tag == 50 || self.tag == 52) {
            [self initSubViews];
        }
        //路途中大头针
        else if(self.tag == 51)
        {
            [self initSmallSubViews];
        }
 
    }
    return self;
}
- (void)initSmallSubViews
{
    CGFloat timeLableX = 10;
    CGFloat timeLabelY = 5;
    CGFloat timeLabelW = self.frame.size.width - timeLableX * 2;
    CGFloat timeLabelH = 15;
    
    CGFloat distanceX = timeLableX;
    CGFloat distanceY = timeLabelY  + timeLabelH;
    CGFloat distanceW = timeLabelW;
    CGFloat distanceH = 25;
    
    CGFloat unitX = distanceX;
    CGFloat unitY = distanceY + distanceH;
    CGFloat unitW = distanceW;
    CGFloat unitH = timeLabelH;
    
    // 添加时间label
    self.smallViewTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(timeLableX ,timeLabelY, timeLabelW, timeLabelH)];
    self.smallViewTimeLabel.font = [UIFont systemFontOfSize:14];
    self.smallViewTimeLabel.textColor = [UIColor whiteColor];
    self.smallViewTimeLabel.text = @"11:20:15";
    self.smallViewTimeLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.smallViewTimeLabel];
    
    // 添加距离label
    self.smallViewDistanceLabel = [[UILabel alloc] initWithFrame:CGRectMake(distanceX ,distanceY, distanceW, distanceH)];
    self.smallViewDistanceLabel.font = [UIFont boldSystemFontOfSize:18];
    self.smallViewDistanceLabel.textColor = [UIColor whiteColor];
    self.smallViewDistanceLabel.text = @"50l";
    self.smallViewDistanceLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.smallViewDistanceLabel];
    
    // 添加单位label
    self.smallViewUnitsLabel = [[UILabel alloc] initWithFrame:CGRectMake(unitX ,unitY, unitW, unitH)];
    self.smallViewUnitsLabel.font = [UIFont systemFontOfSize:14];
    self.smallViewUnitsLabel.textColor = [UIColor whiteColor];
    self.smallViewUnitsLabel.text = @"km/h";
    self.smallViewUnitsLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.smallViewUnitsLabel];
}
- (void)initSubViews
{
    
    // 添加图片，即商户图
    self.portraitView = [[UIImageView alloc] initWithFrame:CGRectMake(kPortraitMargin, kPortraitMargin, kPortraitWidth, kPortraitHeight)];
    
    self.portraitView.backgroundColor = [UIColor blackColor];
    [self addSubview:self.portraitView];
    
    // 添加标题，即商户名
    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(kPortraitMargin * 2 + kPortraitWidth, kPortraitMargin, kTitleWidth, kTitleHeight)];
    self.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.text = @"titletitletitletitle";
    [self addSubview:self.titleLabel];
    
    // 添加副标题，即商户地址
    self.subtitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(kPortraitMargin * 2 + kPortraitWidth, kPortraitMargin * 2 + kTitleHeight, kTitleWidth, kTitleHeight)];
    self.subtitleLabel.font = [UIFont systemFontOfSize:12];
    self.subtitleLabel.textColor = [UIColor lightGrayColor];
    self.subtitleLabel.text = @"subtitleLabelsubtitleLabelsubtitleLabel";
    [self addSubview:self.subtitleLabel];
}
- (void)setTitle:(NSString *)title
{
    self.titleLabel.text = title;
}
- (void)setSubtitle:(NSString *)subtitle
{
    self.subtitleLabel.text = subtitle;
}
- (void)setImage:(UIImage *)image
{
    self.portraitView.image = image;
}
#pragma mark - 重写UIView的drawRect方法，绘制弹出气泡的背景

- (void)drawRect:(CGRect)rect
{

    [self drawInContext:UIGraphicsGetCurrentContext()];
    self.layer.shadowColor = [[UIColor blackColor] CGColor];
    self.layer.shadowOpacity = 1.0;
    self.layer.shadowOffset = CGSizeMake(0.0f, 0.0f);
}
- (void)drawInContext: (CGContextRef)context
{
    CGContextSetLineWidth(context, 2.0);
    CGContextSetFillColorWithColor(context, [UIColor colorWithRed:0 green:0 blue:0
                                                            alpha:0.8].CGColor);
    [self getDrawPath:context];
    CGContextFillPath(context);
     
}
- (void)getDrawPath:(CGContextRef)context
{
    CGRect rrect = self.bounds;
    CGFloat radius = 6.0;
    CGFloat minx = CGRectGetMinX(rrect),
    midx = CGRectGetMidX(rrect),
    maxx = CGRectGetMaxX(rrect);
    CGFloat miny = CGRectGetMinY(rrect),
    maxy = CGRectGetMaxY(rrect)-kArrorHeight;
    

    CGContextMoveToPoint(context, midx+kArrorHeight, maxy);
    CGContextAddLineToPoint(context,midx, maxy+kArrorHeight);
    CGContextAddLineToPoint(context,midx-kArrorHeight, maxy);
    
    CGContextAddArcToPoint(context, minx, maxy, minx, miny, radius );
    CGContextAddArcToPoint(context, minx, minx, maxx, miny, radius);
    CGContextAddArcToPoint(context, maxx, miny , maxx, maxx, radius);
    CGContextAddArcToPoint(context, maxx, maxy, midx, maxy, radius );
    CGContextClosePath(context);
}
@end
