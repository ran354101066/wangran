//
//  CustomCalloutView.h
//  TestMapTrajectory
//
//  Created by wr on 15/6/17.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCalloutView : UIView
- (instancetype)initWithFrame:(CGRect)frame withTag:(NSInteger)selfTag;
@property (nonatomic, strong) UIImage *image; //商户图
@property (nonatomic , copy)NSString * title; //商户名
@property (nonatomic , copy)NSString * subtitle; //地址
@end
