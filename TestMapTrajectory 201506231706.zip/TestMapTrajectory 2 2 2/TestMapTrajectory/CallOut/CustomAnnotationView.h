//
//  CustomAnnotationView.h
//  TestMapTrajectory
//
//  Created by wr on 15/6/17.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import <AMapNaviKit/AMapNaviKit.h>
#import "CustomCalloutView.h"
@interface CustomAnnotationView : MAAnnotationView
@property (nonatomic, readonly) CustomCalloutView *calloutView;
@end
