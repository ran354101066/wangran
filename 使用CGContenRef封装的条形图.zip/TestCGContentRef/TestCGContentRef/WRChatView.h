//
//  WRChatView.h
//  TestCGContentRef
//
//  Created by wr on 15/6/30.
//  Copyright (c) 2015年 WR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WRChatView : UIView

-(instancetype)initWithFrame:(CGRect)frame
               selfBackColor:(UIColor *)backColor
                   starPoint:(CGPoint)startPoint
                 valuesArray:(NSMutableArray *)valuesArray
                    maxValue:(float)maxValue
              textIndicators:(NSMutableArray *)textIndeicators
                   textColor:(UIColor *)textColor
                 barMaxWidth:(float)barMaxWidth
                   barHeight:(float)barHeigh
                cornerRedius:(CGFloat)cornerRedius;

@end
