//
//  ViewController.m
//  TestCGContentRef
//
//  Created by wr on 15/6/30.
//  Copyright (c) 2015年 WR. All rights reserved.
//

#import "ViewController.h"
#import "WRChatView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    WRChatView * chatView = [[WRChatView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - 100) selfBackColor:[UIColor yellowColor] starPoint:CGPointMake(80, 80) valuesArray:[NSMutableArray arrayWithObjects:@8,@8,@5,@4,@1, nil] maxValue:10.0 textIndicators:[NSMutableArray arrayWithObjects:@"5月3日", @"5月10日", @"6月3日", @"10月3日", @"11月11日", nil] textColor:[UIColor blackColor] barMaxWidth:28 barHeight:50 cornerRedius:80];
    [self.view addSubview:chatView];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
