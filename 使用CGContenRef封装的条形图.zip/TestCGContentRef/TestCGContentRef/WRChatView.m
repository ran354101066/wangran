//
//  WRChatView.m
//  TestCGContentRef
//
//  Created by wr on 15/6/30.
//  Copyright (c) 2015年 WR. All rights reserved.
//

#import "WRChatView.h"


#define Line_X 0
@interface WRChatView ()
@property (nonatomic , strong) NSMutableArray * valuesArray;
@property (nonatomic) float maxValue;
@property (nonatomic , strong) NSMutableArray * textIndicators;
@property (nonatomic , strong) UIColor * textColor;
@property (nonatomic ) float barHeight;
@property (nonatomic ) float barMaxWidth;
@property (nonatomic ) CGPoint startPoint;
@property (nonatomic ) CGFloat cornerRedius;
@end

@implementation WRChatView

-(instancetype)initWithFrame:(CGRect)frame
               selfBackColor:(UIColor *)backColor
                   starPoint:(CGPoint)startPoint
                 valuesArray:(NSMutableArray *)valuesArray
                    maxValue:(float)maxValue
              textIndicators:(NSMutableArray *)textIndeicators
                   textColor:(UIColor *)textColor
                 barMaxWidth:(float)barMaxWidth
                   barHeight:(float)barHeigh
                cornerRedius:(CGFloat)cornerRedius
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = backColor;
        _valuesArray = [NSMutableArray arrayWithArray:valuesArray];
        _maxValue = maxValue;
        _textIndicators = [NSMutableArray arrayWithArray:textIndeicators];
        _textColor = textColor;
        _barMaxWidth = barMaxWidth;
        _startPoint = startPoint;
        _cornerRedius = cornerRedius;
    }
    return self;
    
}
#pragma  mark - 返回下部需要显示时间的label
- (UILabel *)loadTimeLabel:(NSString *)labelTitle withFrame:(CGRect)frame withTextColor:(UIColor*)textColor withBackColor:(UIColor *)backColor withFont:(CGFloat)fontFloat
{
    UILabel * label = [[UILabel alloc]initWithFrame:frame];
    [label setTextColor:textColor];
    label.backgroundColor = backColor;
    [label setText:labelTitle];
    [label setTextAlignment:NSTextAlignmentRight];
    label.font = [UIFont systemFontOfSize:fontFloat];
//    [self addSubview:label];
    
    CGAffineTransform transform;
    transform = CGAffineTransformRotate(label.transform, M_PI / 2 * 3);
    [UILabel beginAnimations:@"rotate" context:nil];
    [UILabel setAnimationDuration:0];
    [UILabel setAnimationDelegate:self];
    [label setTransform:transform];
    
    return label;
}
- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    //绘制圆形
    CGFloat cornerR = _cornerRedius;
    CGRect aRect = CGRectMake([UIScreen mainScreen].bounds.size.width / 2 - cornerR , _startPoint.y, cornerR * 2, cornerR * 2);
    CGContextSetRGBStrokeColor(context, 0.6, 0.96, 0, 1.0);
    CGContextSetLineWidth(context, 3.0);
    CGContextAddEllipseInRect(context, aRect);
    CGContextDrawPath(context, kCGPathStroke);
    
    
    //绘制横线
    //条形总高度
    CGFloat barTotalH = 230;

    CGFloat lineY = aRect.origin.y + aRect.size.height + 10 + barTotalH;
    CGContextSetLineWidth(context, 1.0);
    CGContextMoveToPoint(context, Line_X, lineY);
    CGContextAddLineToPoint(context, self.frame.size.width, lineY);
    CGContextStrokePath(context);
    
    
    //绘制条形
    for (int index = 0; index < self.valuesArray.count; index ++) {
        CGFloat barW = 20;
        CGFloat barH = ([_valuesArray[index] intValue]/ _maxValue) * barTotalH;
        CGFloat barY = lineY - barH;
        CGFloat barX = 15 * (index + 1) + barW * index;
        CGContextSetFillColorWithColor(context, [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5f].CGColor);
        CGContextFillRect(context, CGRectMake(barX, barY, barW, barH));
        CGContextStrokePath(context);

        //上端值的label
        CGFloat vLabelW = 30;
        CGFloat vLabelH = 20;
        CGFloat vLabelX = 10 * (index + 1) + (vLabelW - 5) * index;
        CGFloat vLabelY = barY - vLabelH - 10;
        
        UILabel * valueLabel = [[UILabel alloc]initWithFrame:CGRectMake(vLabelX, vLabelY, vLabelW, vLabelH)];
        valueLabel.textAlignment = NSTextAlignmentCenter;
        valueLabel.backgroundColor = [UIColor whiteColor];
        valueLabel.text = [_valuesArray[index] stringValue];
        valueLabel.textColor = _textColor;
        [self addSubview:valueLabel];
        
        //条形下边时间label
        CGFloat labelW = 70;
        CGFloat labelH = 20;
        CGFloat labelX = barX - 20;
        CGFloat labelY = lineY + labelW / 2;
        
        UILabel * timeLabel = [self loadTimeLabel:_textIndicators[index] withFrame:CGRectMake(labelX, labelY, labelW, labelH) withTextColor:[UIColor redColor] withBackColor:[UIColor whiteColor] withFont:15];
        [self addSubview:timeLabel];
    }


}
- (void)setValuesArray:(NSMutableArray *)valuesArray
{
    [self setNeedsDisplay];
}

/*
 Only override drawRect: if you perform custom drawing.
 An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
     Drawing code
}
*/

@end
