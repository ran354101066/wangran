//
//  slideView.m
//  TestMapSlide
//
//  Created by wr on 15/6/12.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "slideView.h"
#import "WRPlayer.h"
@interface slideView()<WRPlayerDelegare>
@property (weak, nonatomic) IBOutlet UIButton *playPauseButton;
@property (weak, nonatomic) IBOutlet UISlider *progressSlide;

@property (retain, nonatomic) WRPlayer * player;
@end
@implementation slideView
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(void)awakeFromNib{
    
    [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Pause"] forState:UIControlStateNormal];
    
    self.player = [[WRPlayer alloc] init];
    self.player.playerDelegate = self;
    
    UIColor *tintColor = [UIColor orangeColor];
    [[UISlider appearance] setMinimumTrackTintColor:tintColor];
}
- (IBAction)progressSlideClick:(UISlider *)sender {
    
     self.player.position = sender.value;
    
}

- (IBAction)playPauseButtonClick:(UIButton *)sender {
    
    if(sender.selected) // Shows the Pause symbol
    {
        [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Play"] forState:UIControlStateNormal];
        sender.selected = NO;
        [self.player pause];
    }
    else    // Shows the Play symbol
    {
        [self.playPauseButton setBackgroundImage:[UIImage imageNamed:@"Pause"] forState:UIControlStateNormal];
        sender.selected = YES;
        [self.player play];
    }
    
}
- (void) player:(WRPlayer *)player didReachPosition:(float)position
{
    //    self.progressView.progress = position;
    self.progressSlide.value = position;
}

- (void) playerDidStop:(WRPlayer *)player
{
    self.playPauseButton.selected = NO;
    //    self.progressView.progress = 0.0;
    self.progressSlide.value = 0.0;
}
@end
