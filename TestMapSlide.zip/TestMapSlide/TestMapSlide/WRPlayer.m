//
//  WRPlayer.m
//  TestMapSlide
//
//  Created by wr on 15/6/12.
//  Copyright (c) 2015年 user. All rights reserved.
//

#import "WRPlayer.h"
#define DURATION 100.0
#define PERIOD 0.05
@interface WRPlayer()
{
    NSTimer * timer;
}
@end
@implementation WRPlayer

@synthesize position;  // 0..1

@synthesize playerDelegate;
- (void)dealloc
{
    [timer invalidate];
    
}

- (void) play
{
    if(timer)
        return;
    
    timer = [NSTimer scheduledTimerWithTimeInterval:PERIOD target:self selector:@selector(timerDidFire:) userInfo:nil repeats:YES];
}
- (void) pause
{
    [timer invalidate];
    timer = nil;
}

- (void) timerDidFire:(NSTimer *)theTimer
{
    if(self.position >= 1.0)
    {
        self.position = 0.0;
        [timer invalidate];
        timer = nil;
        [self.playerDelegate playerDidStop:self];
    }
    else
    {
        self.position += PERIOD/DURATION;
        [self.playerDelegate player:self didReachPosition:self.position];
    }
}
@end
