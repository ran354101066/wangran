//
//  WRViewController.m
//  WRChangeButton
//
//  Created by wr on 15/4/7.
//  Copyright (c) 2015年 WR. All rights reserved.
//

#import "WRViewController.h"

@interface WRViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIButton *changeButton;


//添加左右滑手势
@property(nonatomic,strong)UISwipeGestureRecognizer * leftSwipeGestureRecognizer;
@property(nonatomic,strong)UISwipeGestureRecognizer * rightSwipeGestureRecognizer;
@end

@implementation WRViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.leftSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(handlSwipes:)];
    self.rightSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(handlSwipes:)];
    self.leftSwipeGestureRecognizer.direction=UISwipeGestureRecognizerDirectionLeft;
    self.rightSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    
    [self.changeButton  addGestureRecognizer:self.leftSwipeGestureRecognizer];
    [self.changeButton addGestureRecognizer:self.rightSwipeGestureRecognizer];
}
-(void)handlSwipes:(UISwipeGestureRecognizer * )sender
{
    //左滑
    if(sender.direction == UISwipeGestureRecognizerDirectionLeft)
    {
        if (self.changeButton.frame.origin.x + 20 > self.imageView.frame.origin.x+ self.imageView.frame.size.width / 2) {
            self.changeButton.frame = CGRectMake(self.imageView.frame.origin.x,self.changeButton.frame.origin.y, self.changeButton.frame.size.width, self.changeButton.frame.size.height);
        }
        
    }
    //右滑
    if(sender.direction == UISwipeGestureRecognizerDirectionRight)
    {
        if (self.changeButton.frame.origin.x + 20 < self.imageView.frame.origin.x+ self.imageView.frame.size.width / 2)
        {
            self.changeButton.frame = CGRectMake(self.imageView.frame.origin.x + self.imageView.frame.size.width - self.changeButton.frame.size.width, self.changeButton.frame.origin.y, self.changeButton.frame.size.width, self.changeButton.frame.size.height);
        }
        
    }

}
- (IBAction)buttonClick:(UIButton *)sender {
    
    if (sender.frame.origin.x + 20 < self.imageView.frame.origin.x+ self.imageView.frame.size.width / 2) {
        self.changeButton.frame = CGRectMake(self.imageView.frame.origin.x + self.imageView.frame.size.width - self.changeButton.frame.size.width, self.changeButton.frame.origin.y, self.changeButton.frame.size.width, self.changeButton.frame.size.height);
        
    }else
    {
        self.changeButton.frame = CGRectMake(self.imageView.frame.origin.x,self.changeButton.frame.origin.y, self.changeButton.frame.size.width, self.changeButton.frame.size.height);
    
    }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
